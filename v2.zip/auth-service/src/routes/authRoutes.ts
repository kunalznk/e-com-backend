import { Router } from "express";
import authController from "../controllers/authController";

const authRoute = Router();


authRoute.post("/signup" , authController.signUp);
authRoute.post("/signin" , authController.signIn)
// authRoute.post("/resetpassword", resetpassword)
// authRoute.patch("/updatepassword", updatePassword)
// authRoute.post("/verifyemail/:token", verifyEmail)
// authRoute.post("/verifyemail/resend", resendVerifyEmail)


export default authRoute;